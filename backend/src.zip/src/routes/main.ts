import express from 'express';
import { authRouter } from './auth';
import { interviewRouter } from './interview';
import { getTestCases } from '../db/testCasesQueries/getTestCases';
import { dashboardRouter } from './dashboard';
import { sessionRouter } from './sessions';

const mainRouter = express.Router();

mainRouter.get("/", (req, res) =>{
    res.json({
        message: "hello from the backend "
    })
    
})
mainRouter.use("/auth", authRouter)
mainRouter.use("/interview", interviewRouter)
mainRouter.use("/dashboard", dashboardRouter)
mainRouter.use("/session", sessionRouter)

export {mainRouter}