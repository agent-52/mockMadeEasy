import { prisma } from "./db";
import { Difficulty, InterviewRole, Mode, Status, SubjectType } from "@prisma/client";

function shuffle<T>(array: T[]): T[] {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))

    const temp = array[i]!
    array[i] = array[j]!
    array[j] = temp
  }
  return array
}


export async function createInterviewRecord(userId:number, difficulty:Difficulty, topicIds:number[], numberOfQuestions:number, roleType:InterviewRole, subjects:SubjectType[]){
    
    

    return await prisma.$transaction(async (tx) =>{
        const interview = await tx.interview.create({
            data:{
                subjects: subjects,
                roleType,
                difficulty,
                status:Status.active,
                userId:userId
            }
        })
        const questions = await tx.question.findMany({
            where:{
                topics:{
                    some:{
                        topic:{
                            subject:{
                                title: {in: subjects}
                            }
                        }
                    },
                    ...(topicIds && topicIds.length > 0 ?{
                        topicId: {in : topicIds}
                    }:{}),
                    
                },  
                
                difficulty,
                followUpToQuesitonId:null
                
            },
            
        })

        if (questions.length < numberOfQuestions) {
            throw new Error("Not enough questions available")
        }

        const shuffled = shuffle(questions)
        const selected = shuffled.slice(0, numberOfQuestions)

        const mapping = selected.map((q, index) => ({interviewId: interview.id, questionId: q.id, order: index+1}))

        const mapQuestionsToInterview = await tx.interviewQuestion.createMany({
            data: mapping
        })

        return interview;
    })
}