import { prisma } from "./db";

async function findAudioLink(hashText:string, voiceId:string) {
    const response = await prisma.ttsCache.findUnique({
        where:{
            textHash_voiceId:{
                textHash:hashText,
                voiceId:voiceId
            }
        },
        
    })
    return response?.audioUrl
}

async function createTtsEntry(textHash:string, text:string, audioUrl:string, voiceId:string) {
    const response = await prisma.ttsCache.create({
        data:{
            text,
            textHash,
            voiceId,
            audioUrl
        }
    })
}
export {findAudioLink, createTtsEntry}
