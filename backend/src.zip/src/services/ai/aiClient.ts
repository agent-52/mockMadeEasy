import { groq } from "./gorqClient"

const DEFAULT_MODEL = "meta-llama/llama-4-maverick-17b-128e-instruct"
const FALLBACK_MODEL = "mixtral-8x7b"
const DEFAULT_TEMPERATURE = 0.2
const MAX_RETRIES = 3
const DEFAULT_MAX_TOKENS = 1500


const aiClient = {
    
}
//token budget control
const MAX_PROMPT_CHAR_LIMIT = 15000

if(prompt.length> MAX_PROMPT_CHAR_LIMIT){
    throw new Error("Prompt too large")
}

//retry + validation engine
