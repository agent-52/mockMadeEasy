import { ElevenLabsClient } from "@elevenlabs/elevenlabs-js";
import { ELEVENLABS_API_KEY } from "../../config/env";

export const elevenLabs = new ElevenLabsClient({
        apiKey:ELEVENLABS_API_KEY
    })