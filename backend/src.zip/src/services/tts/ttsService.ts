
import crypto from "crypto"
import { createTtsEntry, findAudioLink } from "../../db/ttsQueries"
import { elevenLabs } from "./ttsClient"
import { uploadAudio } from "./cloudStorage"


async function generateTtsBuffer(text:string, voiceId:string) {
    const audio = await elevenLabs.textToSpeech.convert(
        voiceId,
        {
            text:text,
            modelId:'eleven_multilingual_v2',
            outputFormat:"mp3_44100_128"
        }
    )

    const chunks = []
    for await (const chunk of audio){
        chunks.push(chunk)
    }
    const audioBuffer = Buffer.concat(chunks) 

    return audioBuffer
}

async function getOrCreateAudio(text:string, voiceId?:string) :Promise<string>{
    if(!voiceId){
         voiceId = "JBFqnCBsd6RMkjVDRZzb"
    }
    const textHash = crypto.createHash("sha256").update(text+voiceId).digest("hex")
    
    //check if audio exist logic
    let audioLink:string = ""
    try {
        const ttsLink = await findAudioLink(textHash,voiceId )
        if(ttsLink != null){
            audioLink = ttsLink
            return audioLink
        }
        
    } catch (error) {
        throw new Error("tts search query failed")
    }

    //audio creation logic
    try {
        const audioBuffer = await generateTtsBuffer(text, voiceId)
        //save it to cloud , get link
        const audioUrl = await uploadAudio(audioBuffer, textHash, voiceId)
        //save it to db
        if(audioUrl){
            await createTtsEntry(textHash, text, audioUrl, voiceId)
        }

        return audioUrl
    } catch (error) {
        throw new Error("TTS generation failed")
    }

    

}


export {getOrCreateAudio}