type TransitionContext = 
    "afterAnswer" | "interviewStart" | "interviewEnd" |"movingNext"|"codingStart" | "thinking"

const transitionPool:Record<TransitionContext, string[]> ={
    afterAnswer: [
    "Hmm, interesting.",
    "Alright.",
    "Got it.",
    "Okay."
  ],

  movingNext: [
    "Let’s move to the next question.",
    "Alright, moving ahead.",
    "Now let’s explore another area.",
    "Let’s shift gears."
  ],

  thinking: [
    "Take your time.",
    "Think it through.",
    "Consider edge cases.",
    "Walk me through your logic."
  ],

  codingStart: [
    "You can start coding now.",
    "Let’s implement this.",
    "Go ahead and write your solution."
  ],

  interviewStart: [
    "Welcome. Let’s begin.",
    "Alright, let’s get started.",
    "We’ll start with something simple."
  ],

  interviewEnd: [
    "That concludes the interview.",
    "Good effort today.",
    "We’ll wrap up here."
  ]
}

let lastLine:string | null = null

export function generateTransition(context:TransitionContext):string{
    const pool = transitionPool[context]
    let line = pool[Math.random()*pool.length]
    while(line == null || line === lastLine){
        
        line = pool[Math.random()*pool.length]
    
    }
    if(line){
        lastLine = line
    }
    return line
}