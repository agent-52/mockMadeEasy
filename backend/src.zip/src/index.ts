import express from "express"
import { mainRouter } from "./routes/main"
import cookieParser from "cookie-parser"
import http from "http"
import "./websocket/transcript/speechServer"
import { setupWebSocket } from "./websocket/transcript/speechServer"
import { evaluateQuestionServiec_ai } from "./services/ai/evaluateQuestionService"
import { Difficulty } from "@prisma/client"
import { evaluateInterviewService_ai} from './services/ai/evaluateInterviewService_ai';

const app = express()
app.use(cookieParser())
app.use(express.json())
app.use("/api", mainRouter)
app.use("/ai", async(req, res) =>{
    const input = {
        roleType: "frontend",
        subjects: ["react"],
        difficulty: "easy",
        totalQuestions: 8,
        accuracyPercent: 65,

        avgScores: {
            clarity: 6,
            conceptDepth: 5,
            logicalThinking: 6,
            confidence: 6,
            codeStructure: null
        },

        strengths: ["understands the basic purpose of useEffect", "Understands the basic purpose of useState", "Understands the basic purpose of statemanagemet"]    ,   // capped to 20
        improvements: ["Provide more specific examples of side effects",
        "Explain the relationship between useEffect and class component lifecycle methods", "give example of statemanagemet"],

        pacingCategory: "slow" 
    }
    
    const aiResponse = await evaluateInterviewService_ai(input)
    console.log(aiResponse)
})
const server = http.createServer(app)

setupWebSocket(server)

server.listen(3000, () =>{
    console.log("app listning on port 3000")
})

export {server}